let newCounter = document.getElementById('counter');
let counterValue = parseInt(newCounter.innerHTML);

function increment() {

    counterValue++; 
    console.log(counterValue)
    document.getElementById('counter').innerHTML = counterValue;

    var consoleLog = document.createElement('p');
    consoleLog.innerHTML = "The counter has been increased by one";
    document.getElementById('counterLogs').appendChild(consoleLog);
    console.log(consoleLog)
}

function decrement() {

    counterValue--;
    console.log(counterValue);
    document.getElementById('counter').innerHTML = counterValue

    var consoleLogDecrement = document.createElement('p');
    consoleLogDecrement.innerHTML = "The counter has been decreased by one";
    document.getElementById('counterLogs').appendChild(consoleLogDecrement);
    console.log(consoleLogDecrement);
}

function reset() {

    counterValue = 0;
    console.log(counterValue);
    document.getElementById('counter').innerHTML = counterValue;

    var consoleLogReset = document.createElement('p');
    consoleLogReset.innerHTML = "The counter has been reset";
    document.getElementById('counterLogs').appendChild(consoleLogReset);
    console.log(consoleLogReset);
}